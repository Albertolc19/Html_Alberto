import Banco.cuentaBancaria;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int datos;
        int ingresarDinero;
        int realizarTranserencia;
        int retirarDinero;
        int camiarClave;
        int conocerSaldo;
        cuentaBancaria Marta = new cuentaBancaria("Marta", 1, 1234, 0);
        cuentaBancaria Julio = new cuentaBancaria("Julio", 2, 5678, 0);
        do {
            System.out.println("Inroduce tu clave de cliente ");
            datos=sc.nextInt();
            System.out.println(cuentaBancaria.identificarCliente(datos));
        } while (datos != 1234 && datos != 5678);
        do{
            switch (e){
                case 1:
                    System.out.println("Intrduce el dinero que queiras ingrear");
                    ingresarDinero=sc.nextInt();
                    break;
                case 2:
                    System.out.println("Intrduce el dinero que queiras tranferir y a quien");
                    realizarTranserencia=sc.nextInt();

                    break;
                case 3:
                    retirarDinero=sc.nextInt();
                    break;
                case 4:
                    camiarClave=sc.nextInt();
                    break;
                case 5:
                    conocerSaldo=sc.nextInt();
                    break;
            }
        }while (e==6);

    }
}