public class DVD {
    private String tipo;
    private Compañia compañia;

    public DVD(String tipo, Compañia compañia) {
        this.tipo = tipo;
        this.compañia = compañia;
    }

    @Override
    public String toString() {
        return "DVD{" +
                "tipo='" + tipo + '\'' +
                ", compañia=" + compañia +
                '}';
    }
}
