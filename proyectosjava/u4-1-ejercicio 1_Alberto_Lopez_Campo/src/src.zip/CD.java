public class CD {
    private int pistas;
    private Autor autor;

    public CD(int pistas, Autor autor) {
        this.pistas = pistas;
        this.autor = autor;
    }

    @Override
    public String toString() {
        return "CD{" +
                "pistas=" + pistas +
                ", autor=" + autor +
                '}';
    }
}
