public class BlueRay {
    private int velocidad;
    private int capacidad;

    public BlueRay(int velocidad, int capacidad) {
        this.velocidad = velocidad;
        this.capacidad = capacidad;
    }

    @Override
    public String toString() {
        return "BlueRay{" +
                "velocidad=" + velocidad +
                ", capacidad=" + capacidad +
                '}';
    }
}
