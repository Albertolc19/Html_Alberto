package personas;

class Profesor {
}
